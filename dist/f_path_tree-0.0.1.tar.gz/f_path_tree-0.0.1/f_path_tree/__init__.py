"""
Package for building a file path tree
"""
from .libtree import tree
__version__ = "0.0.1"
__author__ = "VadimTarasov132"